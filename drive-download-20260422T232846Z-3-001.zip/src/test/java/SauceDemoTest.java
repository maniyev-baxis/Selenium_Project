import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.ArrayList;
import java.util.List;

public class SauceDemoTest {
    static void main() throws InterruptedException {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        options.addArguments("--start-maximized");

        WebDriver driver = new ChromeDriver(options);
        driver.get("https://www.saucedemo.com/");

//        driver.findElement(By.id("user-name")).sendKeys("standard_user");
//        driver.findElement((By.id("password"))).sendKeys("secret_sauce");

//        driver.findElement((By.name("user-name"))).sendKeys("standard_user");
//        driver.findElement(By.name("password")).sendKeys("secret_sauce");

//        driver.findElement((By.xpath("//*[@id=\"user-name\"]"))).sendKeys("standard_user");
//        driver.findElement((By.xpath("//*[@id=\"password\"]"))).sendKeys("secret_sauce");

        driver.findElement(By.cssSelector("#user-name")).sendKeys("standard_user");
        driver.findElement(By.cssSelector("#password")).sendKeys("secret_sauce");
//        Thread.sleep(3000);

//        driver.findElement(By.id("login-button")).click();

        driver.findElement(By.name("login-button")).click();
//        Thread.sleep(3000);

        List<WebElement> products = driver.findElements(By.className("inventory_item"));
        System.out.println("Mehsullarin sayi: " + products.size());
        for (int i=0; i < products.size(); i++){
            System.out.println(products.get(i).getText());
        }
//        System.out.println(products.get(0).getText());

//        <div class="card" id="card">
//                <h4>Title</h4>
//                <p>Description...</p>
//                </div>

        driver.findElement(By.cssSelector("#login-button")).click();
        driver.quit();

    }
}
