import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class ChromeTestExample {
    static void main() throws InterruptedException {
//        WebDriver driver = new ChromeDriver();
//        driver.get("https://www.saucedemo.com/");
//        Thread.sleep(2000);
//        driver.quit();

//        WebDriver driver1 = new FirefoxDriver();
//        driver1.get("https://www.saucedemo.com/");
//        Thread.sleep(2000);
//        driver1.quit();
//
//        WebDriver driver2 = new EdgeDriver();
//        driver2.get("https://www.saucedemo.com/");
//        Thread.sleep(2000);
//        driver2.quit();

//        ChromeOptions options = new ChromeOptions();
//        options.addArguments("--incognito");
//        options.addArguments("--start-maximized");
//
//        WebDriver driver = new ChromeDriver(options);
//
//        driver.get("https://www.saucedemo.com/");
//        Thread.sleep(2000);
//        driver.quit();

//        FirefoxOptions options = new FirefoxOptions();
//        options.addArguments("-private");
//
//        WebDriver driver1 = new FirefoxDriver(options);
//        driver1.get("https://www.saucedemo.com/");
//        Thread.sleep(2000);
//        driver1.quit();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
//        options.addArguments("--start-maximized");
        options.addArguments("--window-size=1240,1000");
        options.addArguments("--disable-gpu");

        WebDriver driver = new ChromeDriver(options);
        driver.get("https://www.saucedemo.com/");
        Thread.sleep(2000);
        driver.quit();
    }
}
