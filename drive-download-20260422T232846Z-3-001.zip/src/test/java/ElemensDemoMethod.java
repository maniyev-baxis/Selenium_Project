import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class ElemensDemoMethod {
    static void main() throws InterruptedException, IOException {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        options.addArguments("--start-maximized");

        WebDriver driver = new ChromeDriver(options);
        driver.get("https://www.saucedemo.com/");

        WebElement userName = driver.findElement(By.id("user-name"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement loginBtn = driver.findElement(By.id("login-button"));

//        userName.sendKeys("standard_user", Keys.ENTER);
//        userName.sendKeys("standard_user", Keys.TAB);

//        userName.sendKeys("standard_user");
//        Thread.sleep(1000);
//        userName.sendKeys(Keys.CONTROL, "a");
//        Thread.sleep(1000);
//        userName.sendKeys(Keys.CONTROL, "c");
//        Thread.sleep(1000);
//        userName.clear();
//        Thread.sleep(1000);
//        userName.sendKeys(Keys.CONTROL, "v");
//        loginBtn.isEnabled();
//        loginBtn.isDisplayed();
//        loginBtn.isSelected();

//        String placeholder = userName.getAttribute("placeholder");
//        System.out.println(placeholder);
//        String type = password.getAttribute("type");
//        System.out.println(type);
//
//        String color = password.getCssValue("background-color");
//        System.out.println(color);
//
//        Dimension size = userName.getSize();
//        System.out.println(size.height);
//        System.out.println(size.width);
//
//        Point location = userName.getLocation();
//        System.out.println(location.getX());
//        System.out.println(location.getY());

//
//        userName.clear();
//        userName.sendKeys("standard_user");
//        password.clear();
//        password.sendKeys("secret_sauce");
//        loginBtn.click();
//
//        WebElement homePageTitle = driver.findElement(By.className("title"));
//        String title = homePageTitle.getText();
//        Assert.assertEquals(title,"Products");
//
//        List<WebElement> productNames = driver.findElements(By.className("inventory_item_name"));
//        List<WebElement> productPrices= driver.findElements(By.className("inventory_item_price"));
//
//        for (int i=0; i<productNames.size(); i++){
//            System.out.println("Product name is: " + productNames.get(i).getText() +
//                    " - Product prices is: " + productPrices.get(i).getText());
//        }
//
//        Select selectFilter = new Select(driver.findElement(By.className("product_sort_container")));
//        selectFilter.selectByIndex(2);
//        selectFilter.selectByVisibleText("Price (high to low)");
//        selectFilter.selectByValue("za");

//        driver.switchTo().alert().sendKeys("test");

//        Actions actions = new Actions(driver);
//        actions.contextClick(driver.findElement(By.className("product_sort_container"))).perform();

//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript(
//                "arguments[0].value='standard_user';",userName
//        );
//        Thread.sleep(2000);
//        js.executeScript(
//                "arguments[0].value='secret_sauce';",password
//        );
//        Thread.sleep(2000);
//        js.executeScript(
//                "arguments[0].click();",loginBtn
//        );
//        Thread.sleep(2000);
//
//                js.executeScript(
//                "arguments[0].scrollIntoView(true);",driver.findElement(By.className("social_twitter"))
//        );

        WebElement element = driver.findElement(By.className("login_logo"));
        File screenshot = element.getScreenshotAs(OutputType.FILE);
        File destination = new File("logo.png");
        FileHandler.copy(screenshot, destination);

        Thread.sleep(2000);
        driver.quit();
    }
}
