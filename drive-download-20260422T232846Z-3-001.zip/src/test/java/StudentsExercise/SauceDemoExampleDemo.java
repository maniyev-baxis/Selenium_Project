package StudentsExercise;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SauceDemoExampleDemo {
    public static void main(String[] args) throws InterruptedException {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");
        options.addArguments("--guest");
        options.addArguments("--disable-popup-blocking");
        options.addArguments("--user-data-dir=/tmp/chrome/test-profile");

        Map<String, Object> prefs = new HashMap<>();
        prefs.put("credentials_enable_service", false);
        prefs.put("profile.password_manager_enabled", false);
        prefs.put("profile.password_manager_leak_detection", false);
        options.setExperimentalOption("prefs", prefs);

        WebDriver driver = new ChromeDriver(options);
        driver.get("https://www.saucedemo.com/");

        WebElement userName = driver.findElement(By.id("user-name"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.id("login-button"));

        userName.sendKeys("standard_user");
        password.sendKeys("secret_sauce");
        loginButton.click();

        List<WebElement> items = driver.findElements(By.className("inventory_item"));
        for (WebElement item : items) {
            System.out.println(item.getText());
        }
        List<WebElement> ItemNames = driver.findElements(By.className("inventory_item_name"));
        List<WebElement> ItemPrices = driver.findElements(By.className("inventory_item_price"));
        for (int i = 0; i < ItemNames.size(); i++) {
            System.out.println(ItemNames.get(i).getText() + "-" + ItemPrices.get(i).getText());
        }
//        Select selectItem = new Select(driver.findElement(By.className("inventory_container")));
//        selectItem.selectByVisibleText("Sauce Labs Backpack");
//        selectItem.selectByIndex(1);

driver.quit();

    }
}

