package StudentsExercise;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ShoppingSiteTestAutomation {
    static void main() throws InterruptedException {

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        options.addArguments("--start-maximized");

        WebDriver driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
        driver.get("https://www.demoblaze.com/");

        driver.findElement(By.id("login2")).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));

        WebElement username = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("loginusername"))
        );

        WebElement password = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("loginpassword"))
        );

        username.sendKeys("atest987");
        password.sendKeys("123456");
        driver.findElement(By.xpath("//button[text()='Log in']")).click();

        wait.until(
                ExpectedConditions.invisibilityOfElementLocated(By.id("logInModal"))
        );

        WebElement cattext = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("cat"))
        );

        System.out.println("TEXT: " + cattext.getText());

        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript(
                "arguments[0].scrollIntoView(true);",
                driver.findElement(By.xpath("//a[text()='Phones']")));

        wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//a[text()='Phones']")
        ));

        WebElement phonebtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//a[text()='Phones']")
        ));

                js.executeScript(
                "arguments[0].click();",phonebtn);
//
                Thread.sleep(5000);

                driver.findElement(By.linkText("Korporativ satışlar"));

//        List<WebElement> phones = driver.findElements(By.xpath("//div[@class='col-lg-4 col-md-6 mb-4']"));
//        for (int i = 0; i<phones.size();i++) {
//            System.out.println("Phone: "+phones.get(i).getText());
//        }
//
//        driver.findElement(By.xpath("//a[@href='prod.html?idp_=5']")).click();
//        driver.findElement(By.cssSelector("a[onclick='addToCart(5)']")).click();
//        Alert alert = driver.switchTo().alert();
//        System.out.println(alert.getText());
//        alert.accept();
//
//        driver.findElement(By.xpath("//a[@href= 'cart.html']")).click();
        driver.quit();
    }
}




