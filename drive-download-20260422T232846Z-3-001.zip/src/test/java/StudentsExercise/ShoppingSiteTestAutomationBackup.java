package StudentsExercise;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ShoppingSiteTestAutomationBackup {
    static void main() throws InterruptedException {

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        options.addArguments("--start-maximized");

        WebDriver driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        driver.get("https://www.demoblaze.com/");

        driver.findElement(By.id("login2")).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        WebElement username = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("loginusername"))
        );
        WebElement password = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("loginpassword"))
        );

        username.sendKeys("atest987");
        password.sendKeys("123456");
        driver.findElement(By.xpath("//button[text()='Log in']")).click();

        wait.until(
                ExpectedConditions.invisibilityOfElementLocated(By.id("logInModal"))
        );

        wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("cat"))
        );

        System.out.println("Login uğurludur: " +
                driver.findElement(By.id("cat")).getText());

        JavascriptExecutor js = (JavascriptExecutor) driver;

        wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//a[text()='Phones']"))
        );

        WebElement phonebtn = wait.until(
                ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Phones']"))
        );

        js.executeScript("arguments[0].scrollIntoView(true);", phonebtn);
        js.executeScript("arguments[0].click();", phonebtn);

        System.out.println("Phones kateqoriyasına keçildi.");

        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@class='col-lg-4 col-md-6 mb-4']"))
        );

        System.out.println("Telefonlar yükləndi.");

        Thread.sleep(5000);

        driver.quit();
    }
}