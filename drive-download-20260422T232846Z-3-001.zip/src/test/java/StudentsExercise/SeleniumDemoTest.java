package StudentsExercise;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


//Tapşırıq
//Hər hansı saytın bir hissəsini avtomatlaşdırın.
//Məsələn:
//Sayta daxil olun
//Login edin
//Məhsulları oxuyun
//Bir məhsulu seçin
//Səbətə əlavə edin
//Qiyməti yoxlayın

public class SeleniumDemoTest {

    public static void main(String[] args) throws InterruptedException {

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--incognito");
//        options.addArguments("--disable-notifications");
//        options.addArguments("--guest");
//        options.addArguments("--disable-popup-blocking");
//        options.addArguments("--user-data-dir=/tmp/chrome/test-profile");

//        Map<String, Object> prefs = new HashMap<>();
//        prefs.put("credentials_enable_service", false);
//        prefs.put("profile.password_manager_enabled", false);
//        prefs.put("profile.password_manager_leak_detection", false);
//        options.setExperimentalOption("prefs", prefs);

        WebDriver driver = new ChromeDriver(options);

        driver.get("https://www.saucedemo.com/");

        WebElement username = driver.findElement(By.id("user-name"));
        WebElement password = driver.findElement(By.id("password"));

        username.clear();
        String usernamePlaceholder = username.getAttribute("placeholder");
        Assert.assertEquals(usernamePlaceholder, "Username");
        username.sendKeys("standard_user");

        password.clear();
        String passwordPlaceholder = password.getAttribute("placeholder");
        Assert.assertEquals(passwordPlaceholder, "Password");
        password.sendKeys("secret_sauce");

        WebElement loginBtn = driver.findElement(By.id("login-button"));
        loginBtn.click();

        Thread.sleep(2000);

        List<WebElement> products = driver.findElements(By.className("inventory_item_name"));


        for(WebElement product : products){
            System.out.println(product.getText());
        }

        products.get(1).click();
        Thread.sleep(2000);

        WebElement addToCart = driver.findElement(By.id("add-to-cart"));
        addToCart.click();

        WebElement price = driver.findElement(By.className("inventory_details_price"));
        String productPrice = price.getText();
        System.out.println("Məhsulun qiyməti: " + productPrice);

        Assert.assertTrue(productPrice.contains("$"));


        driver.quit();
    }
}
